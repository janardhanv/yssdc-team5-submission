#!/bin/bash 

chmod 755 *.sh

cd cpp
make distclean
make
